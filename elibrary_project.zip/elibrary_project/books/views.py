from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from .models import Book, Category, BorrowRecord
from .forms import BookForm


def home(request):
    books = Book.objects.all().order_by('-added_date')
    categories = Category.objects.all()
    query = request.GET.get('q', '')
    category_filter = request.GET.get('category', '')

    if query:
        books = books.filter(title__icontains=query) | books.filter(author__icontains=query)
    if category_filter:
        books = books.filter(category__id=category_filter)

    return render(request, 'books/home.html', {
        'books': books,
        'categories': categories,
        'query': query,
        'category_filter': category_filter,
    })


def book_list(request):
    books = Book.objects.all().order_by('-added_date')
    categories = Category.objects.all()
    query = request.GET.get('q', '')
    category_filter = request.GET.get('category', '')

    if query:
        books = books.filter(title__icontains=query) | books.filter(author__icontains=query)
    if category_filter:
        books = books.filter(category__id=category_filter)

    return render(request, 'books/book_list.html', {
        'books': books,
        'categories': categories,
        'query': query,
    })


def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'books/book_detail.html', {'book': book})


@login_required
def borrow_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    already_borrowed = BorrowRecord.objects.filter(user=request.user, book=book, status='borrowed').exists()

    if already_borrowed:
        messages.warning(request, 'You have already borrowed this book.')
    elif not book.is_available():
        messages.error(request, 'No copies available right now.')
    else:
        due_date = timezone.now().date() + timedelta(days=14)
        BorrowRecord.objects.create(user=request.user, book=book, due_date=due_date)
        book.available_copies -= 1
        book.save()
        messages.success(request, f'You borrowed "{book.title}". Due date: {due_date}')

    return redirect('book_detail', pk=pk)


@login_required
def return_book(request, record_id):
    record = get_object_or_404(BorrowRecord, id=record_id, user=request.user)
    if record.status == 'borrowed':
        record.return_date = timezone.now().date()
        record.status = 'returned'
        # Calculate fine (₹5/day after due date)
        if record.return_date > record.due_date:
            overdue_days = (record.return_date - record.due_date).days
            record.fine = overdue_days * 5
        record.save()
        record.book.available_copies += 1
        record.book.save()
        messages.success(request, f'Book returned successfully! Fine: ₹{record.fine}')
    return redirect('user_dashboard')


# ── Admin Views ──────────────────────────────────────────────

@staff_member_required
def admin_dashboard(request):
    total_books = Book.objects.count()
    total_borrowed = BorrowRecord.objects.filter(status='borrowed').count()
    borrow_records = BorrowRecord.objects.all().order_by('-borrow_date')
    return render(request, 'books/admin_dashboard.html', {
        'total_books': total_books,
        'total_borrowed': total_borrowed,
        'borrow_records': borrow_records,
    })


@staff_member_required
def add_book(request):
    form = BookForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Book added successfully!')
        return redirect('admin_dashboard')
    return render(request, 'books/add_book.html', {'form': form, 'title': 'Add Book'})


@staff_member_required
def edit_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    form = BookForm(request.POST or None, request.FILES or None, instance=book)
    if form.is_valid():
        form.save()
        messages.success(request, 'Book updated successfully!')
        return redirect('admin_dashboard')
    return render(request, 'books/add_book.html', {'form': form, 'title': 'Edit Book'})


@staff_member_required
def delete_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    book.delete()
    messages.success(request, 'Book deleted successfully!')
    return redirect('admin_dashboard')
