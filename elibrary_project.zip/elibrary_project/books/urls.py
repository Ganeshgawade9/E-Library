from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('books/', views.book_list, name='book_list'),
    path('books/<int:pk>/', views.book_detail, name='book_detail'),
    path('books/<int:pk>/borrow/', views.borrow_book, name='borrow_book'),
    path('books/return/<int:record_id>/', views.return_book, name='return_book'),

    # Admin URLs
    path('admin-panel/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-panel/add-book/', views.add_book, name='add_book'),
    path('admin-panel/edit-book/<int:pk>/', views.edit_book, name='edit_book'),
    path('admin-panel/delete-book/<int:pk>/', views.delete_book, name='delete_book'),
]
